# SKILL: SECURITY GUARD

## OBJETIVO
Proteger sistema y datos.
