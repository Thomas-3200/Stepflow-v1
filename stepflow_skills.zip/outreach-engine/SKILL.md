# SKILL: OUTREACH ENGINE

## OBJETIVO
Iniciar conversaciones con leads de forma estratégica.

## CUÁNDO USAR
- captar leads
- iniciar primer contacto

## INPUT
- nombre
- nicho
- canal

## OUTPUT
- mensaje
- clasificación
