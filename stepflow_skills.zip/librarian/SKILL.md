# SKILL: LIBRARIAN

## OBJETIVO
Buscar información dentro del sistema.
