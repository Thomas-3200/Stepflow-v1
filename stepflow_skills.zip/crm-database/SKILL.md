# SKILL: CRM DATABASE

## OBJETIVO
Guardar y organizar datos.

## FUNCIONES
- guardar contactos
- registrar mensajes
- actualizar estado
