# SKILL: QA REVIEW

## OBJETIVO
Validar calidad del sistema.
