# SKILL: SALES CLOSER

## OBJETIVO
Convertir leads en clientes.

## FUNCIONES
- detectar interés
- avanzar cierre
